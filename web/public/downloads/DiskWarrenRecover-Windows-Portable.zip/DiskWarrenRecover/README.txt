===========================================================
 DiskWarren Recover - Portable Zero-Block Edition v1.0.0
===========================================================

QUICK START:
1. Double-click 'Run-DiskWarren.cmd' to launch immediately.
2. If Windows SmartScreen displays 'Windows protected your PC':
   Click 'More info' -> Click 'Run anyway'.
3. Or run DiskWarrenRecover.exe directly.

100% Read-Only Safety Shield: Target disks are NEVER written to.
