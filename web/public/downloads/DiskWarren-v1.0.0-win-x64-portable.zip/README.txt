=============================================================
DiskWarren for Windows - Native PC Storage Intelligence v1.0.0
=============================================================

DiskWarren is a high-speed, privacy-first native Windows storage
analyzer and safe cleanup utility.

Features:
- Instant NTFS Master File Table (MFT) partition traversal
- Developer artifact detection (Visual Studio .vs, NuGet, npm, Cargo, pip)
- WSL2 ext4.vhdx disk compaction optimizer
- AI model detector (Ollama, LM Studio, Hugging Face, GGUF)
- Safe cleanup via Win32 SHFileOperationW (recycles directly to Windows Recycle Bin)
- Zero registry modification, zero system file tampering

HOW TO RUN:
Double-click DiskWarren.exe to launch the portable edition.
No administrative installation required.