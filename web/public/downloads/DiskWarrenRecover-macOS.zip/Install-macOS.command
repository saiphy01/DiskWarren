#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
cd "$DIR"
echo "Configuring DiskWarren Recover for macOS..."
xattr -cr "DiskWarren Recover.app" 2>/dev/null || true
chmod +x "DiskWarren Recover.app/Contents/MacOS/diskwarren-recover"
open "DiskWarren Recover.app"
