#!/bin/bash
xattr -cr 'DiskWarren Recover.app'
open 'DiskWarren Recover.app'
